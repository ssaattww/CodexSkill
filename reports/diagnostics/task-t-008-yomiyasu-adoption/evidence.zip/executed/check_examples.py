﻿from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import venv


repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=False)
records = []


def now():
    return datetime.now(timezone.utc).isoformat()


def write_results():
    (out / 'commands.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8-sig')


def run(name, argv, cwd, expected=0):
    record = {'id': name, 'argv': [str(a) for a in argv], 'cwd': str(cwd), 'started_at': now()}
    try:
        proc = subprocess.run(record['argv'], cwd=cwd, capture_output=True, timeout=120)
        record.update(exit_code=proc.returncode, stdout=proc.stdout.decode('utf-8', errors='replace'), stderr=proc.stderr.decode('utf-8', errors='replace'))
    except Exception as exc:
        record.update(exit_code=None, exception=repr(exc), stdout='', stderr='')
    record['finished_at'] = now()
    record['result'] = 'passed' if record['exit_code'] == expected else 'failed'
    records.append(record)
    write_results()
    print(json.dumps({'id': name, 'result': record['result'], 'exit_code': record['exit_code']}), flush=True)
    if record['result'] != 'passed':
        raise RuntimeError(name + ': ' + record.get('exception', record['stderr']))
    return record['stdout']


try:
    head = run('source-head', ['git', 'rev-parse', 'HEAD'], repo).strip()
    run('source-state', ['git', 'status', '--short'], repo)
    run('repository-structure', [sys.executable, '-B', 'scripts/verify_skill_repository.py'], repo)
    run('diff-whitespace', ['git', 'diff', '--check'], repo)

    # The guide's connection example uses a consumer path containing spaces.
    consumer = out / 'consumer with spaces'
    consumer.mkdir()
    run('documented-skill-link', [sys.executable, '-B', 'scripts/link_consumer_skills.py', consumer], repo)
    link = consumer / '.agents' / 'skills'
    assert link.is_symlink() and link.resolve() == (repo / 'skills').resolve()

    tool = out / 'yomiyasu tool'
    pin = '0df47749139dfd64ad3d55e7d53d3839e5874848'
    run('tool-init', ['git', 'init', tool], out)
    run('tool-origin', ['git', '-C', tool, 'remote', 'add', 'origin', 'https://github.com/nanaism/yomiyasu.git'], out)
    run('tool-fetch-pin', ['git', '-C', tool, 'fetch', '--depth=1', 'origin', pin], out)
    run('tool-checkout-pin', ['git', '-C', tool, 'checkout', '--detach', 'FETCH_HEAD'], out)
    assert run('tool-verify-pin', ['git', '-C', tool, 'rev-parse', 'HEAD'], out).strip() == pin

    original = out / 'original paragraph.txt'
    candidate = out / 'candidate paragraph.txt'
    original.write_bytes(('接続が失敗した場合に限り、500 ms 待ってから再試行します。\r\n再試行が3回とも失敗した場合は、出力を停止します。\r\n').encode('utf-8-sig'))
    candidate.write_bytes(('500 ms 待ってから再接続します。失敗した場合は出力を停止します。\r\n').encode('utf-8-sig'))
    before_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [original, candidate]}
    scripts = tool / 'skills' / 'yomiyasu' / 'scripts'
    before = json.loads(run('documented-lint-original', [sys.executable, '-B', scripts / 'yomiyasu_lint.py', original, '--json'], out))
    after = json.loads(run('documented-lint-candidate', [sys.executable, '-B', scripts / 'yomiyasu_lint.py', candidate, '--json'], out))
    diff = json.loads(run('documented-diff', [sys.executable, '-B', scripts / 'yomiyasu_diff.py', original, candidate, '--stance=説明', '--json'], out))
    assert all('findings' in r and 'score' in r for r in [before, after])
    assert isinstance(diff, dict)
    assert before_hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [original, candidate]}

    # Only the task-owned check environment gets this syntax-check dependency.
    checks_env = out / 'checks-env'
    venv.EnvBuilder(with_pip=True).create(checks_env)
    python = checks_env / 'Scripts' / 'python.exe'
    run('yaml-check-dependency', [python, '-m', 'pip', 'install', '--disable-pip-version-check', 'PyYAML==6.0.3'], out)
    template = repo / 'skills' / 'markdown-word-checker' / 'assets' / 'prose-pilot-record.yaml'
    parser_code = 'import pathlib,sys,yaml; p=pathlib.Path(sys.argv[1]); d=yaml.safe_load(p.read_text(encoding="utf-8-sig")); assert d["record_version"]==1; assert d["record_kind"]=="prose_pilot"; assert d["outcome"]["content_acceptance"]=="pending"; print("YAML syntax and pending defaults verified; PyYAML",yaml.__version__)'
    run('template-yaml', [python, '-B', '-c', parser_code, template], out)

    paths = [repo / 'skills' / 'markdown-word-checker' / n for n in ['SKILL.md', 'references/yomiyasu-adoption-guide.md', 'assets/prose-pilot-record.yaml']]
    paths += [repo / 'scripts' / n for n in ['link_consumer_skills.py', 'verify_skill_repository.py', 'run_validation.py']]
    paths += [scripts / n for n in ['yomiyasu_lint.py', 'yomiyasu_diff.py', 'markdown_visibility.py']]
    paths += [Path(__file__).resolve(), original, candidate]
    sources = [{'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
    metadata = {'generated_at': now(), 'repository': 'ssaattww/CodexSkill', 'head': head, 'source_state': 'dirty', 'tool_commit': pin, 'python': sys.version, 'source_files': sources, 'fixture_readonly': True, 'semantic_verdict': 'not asserted by script', 'template_python': str(python)}
    (out / 'source.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8-sig')
    print(json.dumps({'result': 'passed', 'commands': len(records), 'output': str(out)}, ensure_ascii=False), flush=True)
except Exception as exc:
    (out / 'failure.json').write_text(json.dumps({'time': now(), 'exception': repr(exc)}, ensure_ascii=False, indent=2), encoding='utf-8-sig')
    raise
