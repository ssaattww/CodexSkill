﻿from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
evidence = repo.parent / 'CodexSkill-yomiyasu-evidence-20261008'
output = evidence / 'document-checks-02.json'
assert not output.exists()
python = evidence / 'command-examples-01' / 'checks-env' / 'Scripts' / 'python.exe'
template = repo / 'skills' / 'markdown-word-checker' / 'assets' / 'prose-pilot-record.yaml'
parser = '''import sys,yaml
from pathlib import Path
d=yaml.safe_load(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
assert 'proposed_tool' in d['adoption']
assert 'semantic_review' in d['paragraphs'][0]['candidates'][0]
assert 'execution_id' in d['runs'][0]
assert d['outcome']['content_acceptance']=='pending'
print('YAML syntax and pending defaults verified; PyYAML',yaml.__version__)
'''
commands = [
    [str(python), '-X', 'utf8', '-B', '-c', parser, str(template)],
    [str(python), '-X', 'utf8', '-B', str(evidence / 'quick_validate.py'), 'skills/markdown-word-checker'],
    [sys.executable, '-B', 'scripts/verify_skill_repository.py'],
    ['git', 'diff', '--check'],
]
records = []
for args in commands:
    item = {'argv': args, 'cwd': str(repo), 'started_at': datetime.now(timezone.utc).isoformat()}
    try:
        proc = subprocess.run(args, cwd=repo, capture_output=True, timeout=120)
        item.update(exit_code=proc.returncode, stdout=proc.stdout.decode('utf-8', errors='replace'), stderr=proc.stderr.decode('utf-8', errors='replace'))
    except Exception as exc:
        item.update(exit_code=None, stdout='', stderr=repr(exc))
    item['finished_at'] = datetime.now(timezone.utc).isoformat()
    records.append(item)
    output.write_text(json.dumps({'commands': records}, ensure_ascii=False, indent=2), encoding='utf-8-sig')
    print(json.dumps(item, ensure_ascii=False), flush=True)
    if item['exit_code'] != 0:
        raise SystemExit(1)
paths = [repo / 'skills' / 'markdown-word-checker' / n for n in ['SKILL.md', 'references/yomiyasu-adoption-guide.md', 'assets/prose-pilot-record.yaml']]
paths += [Path(__file__), evidence / 'quick_validate.py']
result = {'commands': records, 'files': [{'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths], 'result': 'passed'}
output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8-sig')
