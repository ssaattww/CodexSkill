from __future__ import annotations

import base64
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

repo = Path(sys.argv[1]).resolve()
inputs = Path(sys.argv[2]).resolve()
evidence = repo.parent / 'CodexSkill-yomiyasu-evidence-20261008'
sys.path.insert(0, str(evidence / 'command-examples-01' / 'checks-env' / 'Lib' / 'site-packages'))
import yaml

meta = json.loads((inputs / 'publication-input-meta.json').read_text(encoding='utf-8'))
info = meta['context']
pub = info['publication']
context = deepcopy(info['work_context'])
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == pub['implementationHead']
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=repo, text=True).strip() == pub['branch']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
generated_at = datetime.now(timezone(timedelta(hours=9))).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(value):
    return sha(json.dumps(value, sort_keys=True, ensure_ascii=False).encode('utf-8'))


def write_new(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_bytes(body.encode('utf-8-sig') if isinstance(body, str) else body)


def write_markdown(path, body):
    write_new(path, body.replace('\r\n', '\n').replace('\n', '\r\n'))


skill_files = ['skills/markdown-word-checker/SKILL.md',
               'skills/markdown-word-checker/references/yomiyasu-adoption-guide.md',
               'skills/markdown-word-checker/assets/prose-pilot-record.yaml']
source_files = [{'path': name, 'sha256': sha((repo / name).read_bytes()),
                 'bom': (repo / name).read_bytes().startswith(b'\xef\xbb\xbf'),
                 'crlf': (repo / name).read_bytes().count(b'\r\n'),
                 'lf': (repo / name).read_bytes().count(b'\n')} for name in skill_files]
source_fingerprint = fingerprint(source_files)
diag = repo / pub['diagnosticsPath']
diag.mkdir(parents=True, exist_ok=True)
archive_path = diag / 'evidence.zip'
assert not archive_path.exists()
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ['check_examples.py', 'check_documents.py', 'check_documents-03.py',
                 'quick_validate.py', 'document-checks-02.json', 'document-checks-03.json',
                 'implementation-head.txt', 'pr.json']:
        archive.write(evidence / name, 'executed/' + name)
    for name in ['commands.json', 'source.json', 'original paragraph.txt', 'candidate paragraph.txt']:
        archive.write(evidence / 'command-examples-01' / name, 'executed/command-examples-01/' + name)
    tool = evidence / 'command-examples-01' / 'yomiyasu tool'
    for name in ['yomiyasu_lint.py', 'yomiyasu_diff.py', 'markdown_visibility.py']:
        archive.write(tool / 'skills' / 'yomiyasu' / 'scripts' / name, 'upstream/' + name)
    for license_file in tool.rglob('*LICENSE*'):
        if license_file.is_file() and '.git' not in license_file.relative_to(tool).parts:
            archive.write(license_file, 'upstream/' + license_file.relative_to(tool).as_posix())
    for name in ['report-context.json', 'publication-input-meta.json', 'usage-missing-lint.yaml',
                 'usage-candidate.yaml', 'skill-v1.md']:
        archive.write(inputs / name, 'authoring/' + name)
    archive.write(Path(__file__), 'authoring/generate_records.py')
    for snapshot in meta['snapshots']:
        for item in snapshot['files']:
            data = base64.b64decode(item['data'])
            assert sha(data) == item['sha256']
            archive.writestr('snapshots/' + snapshot['version'] + '/' + item['name'], data)
    for name in skill_files:
        archive.write(repo / name, 'final-technical/' + name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    entries = [{'path': name, 'sha256': sha(archive.read(name)), 'size': len(archive.read(name))}
               for name in archive.namelist()]
archive_hash = sha(archive_path.read_bytes())

examples = json.loads((evidence / 'command-examples-01' / 'commands.json').read_text(encoding='utf-8-sig'))
example_source = json.loads((evidence / 'command-examples-01' / 'source.json').read_text(encoding='utf-8-sig'))
doc2 = json.loads((evidence / 'document-checks-02.json').read_text(encoding='utf-8-sig'))
doc3 = json.loads((evidence / 'document-checks-03.json').read_text(encoding='utf-8-sig'))
assert all(item['exit_code'] == 0 for item in examples + doc2['commands'] + doc3['commands'])
for name in ['usage-missing-lint.yaml', 'usage-candidate.yaml']:
    assert isinstance(yaml.safe_load((inputs / name).read_text(encoding='utf-8-sig')), dict)

commands = []
for group, values, source in [('command-examples-01', examples, example_source['source_files']),
                              ('document-checks-02', doc2['commands'], doc2['files']),
                              ('document-checks-03', doc3['commands'], doc3['files'])]:
    for item in values:
        commands.append({'command': subprocess.list2cmdline(item['argv']),
                         'purpose': group + '/' + item.get('id', 'document validation'),
                         'exit_code': item['exit_code'], 'result': 'passed',
                         'head_sha': pub['base'],
                         'evidence': pub['diagnosticsPath'] + '/evidence.zip#executed/' + group,
                         'execution_environment': {'kind': 'connected_computer', 'tool': 'RDMCP',
                           'machine_id': 'local', 'os': 'Windows', 'cwd': item['cwd'],
                           'source_state': 'dirty', 'started_at': item['started_at'],
                           'finished_at': item['finished_at']},
                         'source_fingerprint': fingerprint(source)})

report_path = repo / pub['reportPath']
handoff_path = repo / pub['handoffPath']
body = (inputs / 'report-template.md').read_text(encoding='utf-8-sig')
body = body.replace('{{SOURCE_FINGERPRINT}}', source_fingerprint).replace('{{EVIDENCE_SHA256}}', archive_hash)
assert not re.search(r'\{\{[^}]+\}\}', body)
write_markdown(report_path, body)

# Parent invokes progress-sync-manager policy; preserve unrelated tracking and original encoding.
task_block = f'''- T-008: yomiyasu の導入・運用手順を他リポジトリ向けに整理する
  - Status: 手順書・記録様式・掲載コマンド・利用演習・限定契約確認まで完了。報告と引継ぎの永続化は `commit_pending`、最終公開検証は `ci_wait_pending`
  - Phase: Phase 12
  - PR: #91
  - Scope: 既存 `markdown-word-checker` の入口、共通手順、利用先の記録様式
  - Technical HEAD: `{head}`
  - Administrative parent: `{head}`
  - Verification: 固定版の取得と接続・lint・diff、YAML、Skill構文、構造・リンク検査、利用演習2件を確認。`YAD-CR-001` / `YAD-CR-002` は同じ担当が closed を確認
  - Markdown lint: focused/full は利用先形式の設定不在により `unsupported`。この文書変更では制約を報告し、既存の構造・配布検証を必須とする
  - Report: [{Path(pub['reportPath']).name}](../{pub['reportPath']})
  - Handoff: [{Path(pub['handoffPath']).name}](../{pub['handoffPath']})
  - Next: 全記録を含む最終候補で既存full gateを実行し、最終pushとPR更新後にHEAD一致CIを確認する。完了時のSHAと結果はPR #91へ記録し、その後は通常reviewへ渡す

'''
phase_block = f'''\n## Phase 12: yomiyasu のリポジトリ展開手順

- Status: Implementation complete; report persistence and final publication verification pending
- Task: T-008 / PR #91
- Notes:
  - 共通手順と利用先の対象・用語・採用版・受入判断を分ける
  - 原文・試案・最終文、focused/full、技術検証・内容受入を分けて記録する
  - 掲載コマンド、SkillとYAML構文、利用演習2件を確認し、限定契約確認2件は closed
  - 技術HEADは `{head}`。報告・引継ぎ・進捗のcommitは作成時点で `commit_pending`
  - 最終候補のfull gateとHEAD一致CIはこの記録の永続化後に確認し、最終状態をPR #91へ記録する
  - [実施報告](../{pub['reportPath']}) と [引継ぎ](../{pub['handoffPath']}) を通常reviewの入口にする
'''
for name in ['tasks/tasks-status.md', 'tasks/phases-status.md']:
    p = repo / name
    data = p.read_bytes()
    bom = data.startswith(b'\xef\xbb\xbf')
    text = data.decode('utf-8-sig').replace('\r\n', '\n')
    assert text.count('- Updated: 2026-09-15') == 1
    text = text.replace('- Updated: 2026-09-15', '- Updated: 2026-10-08')
    if name.endswith('/tasks-status.md'):
        assert '- T-008:' not in text
        assert text.count('## In Progress\n\n') == 1
        text = text.replace('## In Progress\n\n', '## In Progress\n\n' + task_block)
    else:
        assert '## Phase 12:' not in text
        text = text.rstrip() + '\n' + phase_block
    if b'\r\n' in data:
        text = text.replace('\n', '\r\n')
    p.write_bytes(text.encode('utf-8-sig' if bom else 'utf-8'))

environment = context['execution_environment']
environment.update(head_sha=head, source_state='dirty', source_fingerprint=source_fingerprint)
context.update(current_head=head, issue_or_pr=pub['prUrl'])
context['execution_state'].update(technical_head=head, administrative_parent=head,
    commit='commit_pending', push='push_pending', ci_wait='ci_wait_pending',
    full_local_equivalence_gate={'state': 'not_started', 'candidate_head': 'unknown', 'invalidated_runs': []})
context['unknown'] = ['Future report/tracking commit SHA and its CI do not exist at generation time.']
findings = info['findings']
changed = [{'path': p, 'purpose': purpose} for p, purpose in [
    (skill_files[0], 'Optional adoption discovery and navigation'),
    (skill_files[1], 'Reusable adoption and operation guide'),
    (skill_files[2], 'Manual pilot record template'),
    ('tasks/tasks-status.md', 'T-008 progress under progress-sync-manager'),
    ('tasks/phases-status.md', 'Phase 12 progress under progress-sync-manager'),
    (pub['reportPath'], 'Detailed implementation report'),
    (pub['handoffPath'], 'Lossless schema 3 handoff'),
    (pub['diagnosticsPath'] + '/evidence.zip', 'Source-bound successful and failed evidence'),
    (pub['diagnosticsPath'] + '/manifest.json', 'Archive and source hashes with verification limits')]]
intentionally_untouched = [
    {'path_or_area': 'Existing shared CodexSkill checkout and Duck checkout', 'reason': 'Other working areas; task uses dedicated clone'},
    {'path_or_area': 'Skill owner/required lint flow/hooks and shared runtime scripts', 'reason': 'Documentation-only procedure addition'},
    {'path_or_area': 'Both hierarchy design mirrors and ChatGPT worker release inventory', 'reason': 'No Skill inventory/call-graph/architecture change'},
    {'path_or_area': 'Consumer lint configuration and global machine settings', 'reason': 'Consumer decisions remain local; no adoption changes requested here'}]
failure_diagnostics = [{'type': 'other', 'location': pub['diagnosticsPath'] + '/evidence.zip#authoring/publication-input-meta.json',
                        'summary': note} for note in info['facts']['operational_diagnostics']]
tests = [
    {'name': 'Documented commands with a path containing spaces and pinned upstream SHA', 'phase': 'verification', 'result': 'passed', 'head_sha': pub['base'], 'evidence': pub['diagnosticsPath'] + '/evidence.zip#executed/command-examples-01'},
    {'name': 'Fresh-agent missing-lint adoption exercise; no real consumer operation', 'phase': 'verification', 'result': 'passed', 'head_sha': pub['base'], 'evidence': pub['diagnosticsPath'] + '/evidence.zip#authoring/usage-missing-lint.yaml'},
    {'name': 'Fresh-agent semantic candidate exercise; supplied results are not executed logs', 'phase': 'verification', 'result': 'passed', 'head_sha': pub['base'], 'evidence': pub['diagnosticsPath'] + '/evidence.zip#authoring/usage-candidate.yaml'},
    {'name': 'Post-fix YAML/frontmatter/structure/link validation', 'phase': 'verification', 'result': 'passed', 'head_sha': pub['base'], 'evidence': pub['diagnosticsPath'] + '/evidence.zip#executed/document-checks-03.json'},
    {'name': 'Final committed-candidate full repository gate', 'phase': 'verification', 'result': 'not_run', 'head_sha': 'unknown', 'evidence': 'Run before final push; attach final result in PR #91'}]
risks = ['CodexSkill terminology lint remains unsupported; structural/build validation does not replace wording lint.',
         'Usage exercises are simulated scenarios, not deployments to two real repositories.',
         'CLI examples were executed on Windows; other operating systems were not exercised here.',
         'A full normal review and independent final review have not been performed.',
         'This packet predates its own commit and final CI; consult PR #91 final publication metadata.']
implementation = {'mode': 'initial_implementation', 'accepted_scope': context['scope'], 'non_goals': context['non_goals'],
    'requirements_and_design_references': context['authoritative_requirements'], 'changed_files': changed,
    'intentionally_untouched': intentionally_untouched, 'validation_commands_and_results': commands,
    'tests': tests, 'failure_diagnostics': failure_diagnostics,
    'artifacts': [{'path': pub['diagnosticsPath'] + '/evidence.zip', 'sha256': archive_hash}],
    'verification_capability': 'local_execution_available', 'execution_environment': deepcopy(environment),
    'source_bound_validation_evidence': {'source_fingerprint': source_fingerprint, 'files': source_files},
    'review_target_commit': head, 'commit_state': 'commit_pending', 'push_state': 'push_pending',
    'ci_wait_state': 'ci_wait_pending', 'matching_ci': None, 'final_technical_head': head,
    'administrative_parent': head, 'addressed_findings': findings, 'blocked_items': [],
    'unknowns': context['unknown'], 'remaining_risks': risks,
    'next_required_action': 'Commit report/tracking, run final full gate before push, update PR, verify final exact-head CI, then normal review.'}
report_result = {'report_type': 'implementation_report', 'complete_body': body,
    'evidence_sources': [pub['diagnosticsPath'] + '/evidence.zip', pub['diagnosticsPath'] + '/manifest.json'],
    'target_identity': {'branch': pub['branch'], 'base_ref': 'main', 'current_head': head, 'reviewed_implementation_head': None},
    'verification': {'capability': 'local_execution_available', 'technical_head': head, 'administrative_parent': head,
                     'commit_state': 'commit_pending', 'push_state': 'push_pending', 'ci_wait_state': 'ci_wait_pending'},
    'execution_environment': deepcopy(environment),
    'independent_closure': {'initial_independent_reviewed_head': None, 'closure_reviewed_heads': [], 'reviewer_continuity': None, 'closure_scope': [], 'completeness_matrix': []},
    'severity_records': [{'finding_id': f['id'], 'source_severity': f['severity'], 'new_severity': None, 'reason': None, 'approved_by': None, 'record_type': 'preserved'} for f in findings],
    'persistence': {'mode': 'repository_file', 'reserved_paths': [pub['reportPath']], 'report_attestation_head': None},
    'concise_pr_comment_body': None, 'unresolved_discrepancies': []}

# Complete typed projection and complete producing-core payloads; future commit identity stays pending.
packet = {
    'schema_version': 3,
    'producer': {'skill': 'chat-implementation-worker', 'mode': 'initial_implementation', 'generated_at': generated_at},
    'repository': pub['repo'], 'issue_or_pr': pub['prUrl'], 'task_id': 'T-008', 'branch': pub['branch'], 'base_ref': 'main',
    'target': {'current_head': head, 'reviewed_head': None, 'commit_range': pub['base'] + '..' + head},
    'execution_environment': deepcopy(environment),
    'verification': {'capability': 'local_execution_available', 'capability_evidence': context['verification_capability_evidence'],
        'technical_head': head, 'administrative_parent': head,
        'commit': {'state': 'commit_pending', 'review_target_sha': head},
        'push': {'state': 'push_pending', 'head_sha': 'unknown'},
        'ci_wait': {'state': 'ci_wait_pending', 'required_for': 'merge_gate'},
        'final_publication': {'sequence': 'final_push_then_authorized_pr_create_or_update_then_exact_head_pull_request_ci_wait', 'pr_action': 'update'}},
    'authoritative_requirements': context['authoritative_requirements'],
    'development_policy': dict(context['development_policy'], governing_source='AGENTS.md'),
    'validation_plan': {'commands': context['validation']['commands'], 'required_failure_diagnostics': context['validation']['required_failure_diagnostics']},
    'blocked': [],
    'authorized_actions': ['read_repository', 'edit_documentation', 'write_handoff', 'write_report', 'create_branch', 'commit', 'push', 'create_pr', 'update_pr', 'comment_pr'],
    'write_boundary': {'allowed': [{'path_or_operation': p, 'reason': 'Current user-authorized task'} for p in context['write_boundary']['allowed']],
                      'forbidden': [{'path_or_operation': p, 'reason': 'Outside task scope or merge boundary'} for p in context['write_boundary']['forbidden']]},
    'scope': context['scope'], 'non_goals': context['non_goals'],
    'files': {'changed': changed, 'inspected': [{'path': p, 'purpose': 'Authoritative procedure/validation contract'} for p in [
        'AGENTS.md', 'skills/skill-authoring-wrapper/SKILL.md', 'skills/markdown-word-checker/SKILL.md',
        'design/markdown-word-check-skill-design.md', 'design/review-enforcer-markdown-whitelist-rebuild-design.md',
        'skills/progress-sync-manager/SKILL.md', 'skills/report-output-manager/references/report-filename-policy.md',
        'scripts/link_consumer_skills.py', 'scripts/verify_skill_repository.py', 'scripts/run_validation.py',
        'scripts/build_chatgpt_worker_skills.py', '.github/workflows/pr-commit-artifacts.yml', '.github/workflows/release-chatgpt-worker-skills.yml']],
        'intentionally_untouched': intentionally_untouched},
    'commands': commands, 'tests': tests,
    'ci': {'required': True, 'workflow': 'Validate and release ChatGPT worker skills; PR commit artifacts',
           'run_id': None, 'head_sha': 'unknown', 'conclusion': 'unknown', 'artifacts': []},
    'implementation': {'outcome': 'completed', 'final_head': head,
        'commits': [{'sha': head, 'purpose': 'Reusable guide, manual record and optional Skill discovery'}],
        'addressed_findings': [{'id': f['id'], 'reviewed_head': pub['base'], 'disposition': 'addressed', 'evidence': f['closure_evidence']} for f in findings],
        'failure_diagnostics': failure_diagnostics, 'blocked_items': [],
        'summary': ['Technical documentation commit is pushed; report/tracking publication and final verification are pending at packet generation.']},
    'review': {'mode': 'not_applicable', 'reviewed_head': 'unknown',
        'reviewer': {'identity': 'unknown', 'role': 'not_applicable',
            'continuity': {'previous_reviewer_identity': None, 'changed': False, 'reason': None},
            'independence': {'implemented_change': 'unknown', 'implemented_review_fix': 'unknown', 'served_as_normal_reviewer': 'unknown', 'inherited_conversation': 'unknown', 'evidence': []}},
        'verdict': 'not_applicable', 'required_coverage': [],
        'independent_closure': {'initial_independent_reviewed_head': None, 'closure_reviewed_heads': [], 'reviewer_continuity': None, 'closure_scope': [], 'completeness_matrix': []},
        'validation_assessment': [{'item': 'Terminology lint focused/full', 'result': 'unsupported', 'evidence': 'No repo-local wording lint wiring; caller accepts this documented limitation.'}],
        'reserved_report_paths': [],
        'report_attestation': {'allowed': 'not_applicable', 'reviewed_implementation_head': None, 'allowed_paths': [],
            'required_first_parent': None, 'maximum_commits_after_reviewed_head': None, 'forbidden_path_classes': [],
            'no_later_commits_required': 'not_applicable', 'validation_status': 'not_applicable', 'validation_evidence': []},
        'summary': ['Focused contract validation and finding closure are recorded in extensions; no full normal or independent final review is claimed.']},
    'report': {'report_type': 'implementation_report', 'outcome': 'created', 'persistence_mode': 'repository_file',
        'paths': [pub['reportPath']], 'reviewed_head': None, 'attestation_head': None, 'pr_comments': [],
        'summary': ['Detailed report generated before its own persistence commit; final publication evidence will be in PR #91.']},
    'findings': [{k: f[k] for k in ['id', 'severity', 'origin', 'location', 'description', 'impact', 'evidence', 'required_action']} for f in findings],
    'held': [{'item': 'Full normal review', 'reason': 'Not performed in this implementation task', 'owner': 'next reviewer', 'remaining_risk': 'Focused validation does not constitute full review', 'verdict_impact': 'No full review verdict claimed'}],
    'unexplored': [{'area': 'Real adoption in other repositories and non-Windows execution', 'blocker': 'Outside this documentation task', 'remaining_risk': 'Consumer-specific setup remains to be verified', 'verdict_impact': 'No deployment or cross-platform result claimed'}],
    'unknown': [{'field_or_fact': 'Future persistence commit and final CI', 'reason': 'This packet is generated before that commit'}],
    'not_applicable': [{'field_or_area': 'Independent review attestation and merge', 'reason': 'Implementation report only; merge is not authorized'}],
    'remaining_risks': risks,
    'source_payloads': [
        {'source_skill': 'work-context-manager', 'output_contract_version': 'attachment-sha256:' + meta['attachment_sha256'], 'content_type': 'application/json', 'payload': context},
        {'source_skill': 'implementation-worker', 'output_contract_version': 'attachment-sha256:' + meta['attachment_sha256'], 'content_type': 'application/json', 'payload': implementation},
        {'source_skill': 'report-writer', 'output_contract_version': 'attachment-sha256:' + meta['attachment_sha256'], 'content_type': 'application/json', 'payload': report_result}],
    'extensions': [{'namespace': 'codexskill.yomiyasu-adoption', 'payload': {
        'focused_contract_validation': {'reviewer': '/root/guide_contract_check', 'findings': findings, 'closure_scope': 'same reviewer, two findings and their fixes only'},
        'usage_exercises': info['facts']['usage_scenarios'], 'operational_diagnostics': info['facts']['operational_diagnostics'],
        'source_files': source_files, 'evidence_archive_sha256': archive_hash,
        'ci_routing': 'After final push, require actual same-repo push artifact validation and exact-head pull_request build; synchronize collect no-op is insufficient.'}}],
    'next_action': {'type': 'review', 'target_skill': 'chat-review-worker', 'mode': 'initial_review',
        'summary': 'After confirming the final publication record, review PR #91 against the procedure and existing contracts.',
        'instructions': ['Re-resolve PC, writable area, current branch/HEAD and dependencies before reuse.',
            'Read PR #91 final publication comment for final HEAD/full gate/CI; this packet predates its own commit.',
            'Use a new authorized review task; current permissions do not transfer automatically.', 'Do not merge.'],
        'required_attachments_or_references': [pub['prUrl'], pub['reportPath'], pub['handoffPath'], pub['diagnosticsPath'] + '/manifest.json'],
        'requested_authorized_actions': ['read_repository', 'write_report', 'write_handoff', 'comment_pr']},
    'transport': {'method': 'repository_file', 'packet_path': pub['handoffPath'],
        'packet_url': 'https://github.com/' + pub['repo'] + '/blob/' + pub['branch'] + '/' + pub['handoffPath'],
        'transport_note': 'Repository packet plus full source payloads; revalidate environment and obtain next-task authorization.'}}
packet_text = yaml.safe_dump(packet, allow_unicode=True, sort_keys=False, width=110)
write_markdown(handoff_path, packet_text)
parsed = yaml.safe_load(handoff_path.read_text(encoding='utf-8-sig'))
assert parsed == packet
assert parsed['source_payloads'][0]['payload']['execution_environment'] == parsed['execution_environment']
assert parsed['source_payloads'][2]['payload']['complete_body'] == report_path.read_text(encoding='utf-8-sig')
assert len(parsed['source_payloads']) == 3 and len(parsed['findings']) == 2
assert {f['severity'] for f in parsed['findings']} == {'medium'}

markdown_targets = [skill_files[0], skill_files[1], 'tasks/tasks-status.md', 'tasks/phases-status.md', pub['reportPath']]
manifest = {'generated_at': generated_at, 'repository': pub['repo'], 'pr': pub['prUrl'],
    'technical_head': head, 'base': pub['base'], 'administrative_parent': head,
    'commit_state': 'commit_pending', 'push_state': 'push_pending', 'ci_wait_state': 'ci_wait_pending',
    'source_fingerprint': source_fingerprint, 'source_fingerprint_scope': 'Three technical documentation files as raw Windows working-tree bytes',
    'source_files': source_files,
    'written_text_files': [{'path': item['path'], 'sha256': sha((repo / item['path']).read_bytes()),
        'bom': (repo / item['path']).read_bytes().startswith(b'\xef\xbb\xbf'),
        'crlf': (repo / item['path']).read_bytes().count(b'\r\n'),
        'lf': (repo / item['path']).read_bytes().count(b'\n')}
        for item in changed if item['path'].endswith(('.md', '.yaml'))],
    'evidence_archive': {'path': pub['diagnosticsPath'] + '/evidence.zip', 'sha256': archive_hash,
        'size': archive_path.stat().st_size, 'entries': entries},
    'checks': {'documented_command_support': {'commands': len(examples), 'result': 'passed'},
               'post_fix_document_checks': {'commands': len(doc3['commands']), 'result': 'passed'},
               'usage_exercises': {'count': 2, 'result': 'passed', 'real_consumer_execution': False},
               'focused_contract_findings': findings,
               'handoff_yaml_roundtrip_and_source_payload_preservation': 'passed',
               'full_repository_gate': {'state': 'not_run', 'reason': 'Run on final committed candidate before final push'},
               'markdown_lint': {'focused': {'state': 'unsupported', 'explicit_targets': markdown_targets},
                                 'full': {'state': 'unsupported', 'targets': 'unresolved; no repository wording lint configuration'},
                                 'aggregate_state': 'unsupported', 'caller_disposition': 'Document limitation for this procedure-only change; require existing structural/build gate.'}},
    'final_publication_record': pub['prUrl'], 'operational_diagnostics': info['facts']['operational_diagnostics']}
assert not (repo / 'package.json').exists()
assert not (repo / 'tools' / 'lint' / 'markdown-targets.json').exists()
write_new(diag / 'manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
output = {'report': pub['reportPath'], 'handoff': pub['handoffPath'], 'manifest': pub['diagnosticsPath'] + '/manifest.json',
          'evidence_sha256': archive_hash, 'source_fingerprint': source_fingerprint, 'archive_entries': len(entries),
          'generated_at': generated_at, 'changed_paths': [item['path'] for item in changed]}
(evidence / 'records-result.json').write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8-sig')
print(json.dumps(output, ensure_ascii=False, indent=2))
